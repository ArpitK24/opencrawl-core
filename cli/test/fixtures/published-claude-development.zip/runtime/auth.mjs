// Synthetic archive fixture.
