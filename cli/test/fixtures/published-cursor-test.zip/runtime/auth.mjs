inert Cursor test fixture
